# WorkPilot AI — Multi-Agent Execution Plan

## Goal
Get the project running end-to-end by fixing backend bugs and connecting frontend to backend API.

## Approach
Use multiple parallel sub-agents with a master agent orchestrating:

### Wave 1 (Parallel)
- **Agent A (Backend fixes)**: Fix login password verification, store password hash on registration, wire audit logging, implement forgot-password flow, run tests
- **Agent B (Frontend API integration)**: Create `api.js` client module, update `AuthModal.jsx` to sync tokens with backend, update `Dashboard.jsx` for backend logout, add token refresh on app load in `App.jsx`

### Wave 2
- **Agent C (Testing agent)**: Run backend tests, verify frontend-backend integration, fix any bugs found

### Wave 3  
- **Master agent**: Review all changes, configure `.env` files with user's Firebase credentials, final integration check

## Key Files
- Backend: `services/auth_service.py`, `models/user.py`, `api/v1/endpoints/auth.py`
- Frontend: `src/api.js` (new), `src/components/AuthModal.jsx`, `src/components/Dashboard.jsx`, `src/App.jsx`